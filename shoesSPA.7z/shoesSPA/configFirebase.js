const firebaseConfig = {
    apiKey: "AIzaSyA-KPJvD0t_uZVzL7X-UtdRSFJ2mNz4u40",
    authDomain: "serverd1.firebaseapp.com",
    databaseURL: "https://serverd1-default-rtdb.firebaseio.com",
    projectId: "serverd1",
    storageBucket: "serverd1.appspot.com",
    messagingSenderId: "187319031603",
    appId: "1:187319031603:web:2d6cdd4cc4d8bc10e09046"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);