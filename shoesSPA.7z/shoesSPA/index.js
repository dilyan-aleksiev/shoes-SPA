// console.log(Handlebars);
const userModel = firebase.auth();
const DB = firebase.firestore();

const app = Sammy('#root', function () {

    this.use('Handlebars', 'hbs');

    this.get('/home', function (context) {
        console.log(context);
        DB.collection('dataBase')
            .get()
            .then((data) => {
                context.dataBase = [];
                data.forEach((x) => {
                    context.dataBase.push({ id: x.id, ...x.data() });
                })
                // context.dataBase = data.docs.map((x) => { return { id: x.id, ...x.data() } })
                addHeaderFooter(context)
                    .then(function () {
                        this.partial('./templates/home.hbs');
                    })
            })
            .catch((error) => {
                console.log(error);
            })
    })

    this.get('/register', function (context) {
        addHeaderFooter(context)
            .then(function () {
                this.partial('./templates/register.hbs');
            })
    })

    this.post('/register', function (context) {
        // console.log(context);
        const { email, password, rePassword } = context.params;

        if (password !== rePassword) {
            return;
        }

        userModel.createUserWithEmailAndPassword(email, password)
            .then((data) => {
                console.log(data);
                this.redirect('#/login');
            })
            .catch((error) => {
                console.log(error);
            });
    })

    this.get('/login', function (context) {
        addHeaderFooter(context)
            .then(function () {
                this.partial('./templates/login.hbs');
            })
    })

    this.post('/login', function (context) {
        console.log(context);
        const { email, password } = context.params;
        userModel.signInWithEmailAndPassword(email, password)
            .then((data) => {
                console.log(data);
                // const {user} = data;
                // console.log(user);
                const { email, uid } = data.user;
                // console.log((email));
                // console.log((uid));
                localStorage.setItem('user', JSON.stringify({ email, uid }));
                this.redirect('#/home')
            })
            .catch((error) => {
                console.log(error);
            })
    })

    this.get('/editOffer', function (context) {
        addHeaderFooter(context)
            .then(function () {
                this.partial('./templates/editOffer.hbs');
            })
    })

    this.get('/details/:id', function (context) {
        // console.log(context);

        const { id } = context.params;
        // console.log(uniqueStr);
        DB.collection('dataBase')
            .doc(id)
            .get()
            .then((response) => {
                // console.log(response.data());
                const isSalesman = response.data().salesman === getUserInfo().uid;
                // console.log(getUserInfo());
                context.shoesCollection = { ...response.data(), isSalesman, id: id }; // { ... responese.data() };
                // console.log(context);
                // console.log(response.data());
                addHeaderFooter(context)
                    .then(function () {
                        this.partial('./templates/details.hbs');
                    })
            })
    })

    this.get('/delete/:id', function (context) {

        const { id } = context.params;
        // console.log(id);
        DB.collection('dataBase')
            .doc(id)
            .delete()
            .then(() => {
                this.redirect('#/home');
            })
            .catch((error) => {
                console.log(error);
            })
    })

    this.get('/createNewOffer', function (context) {
        addHeaderFooter(context)
            .then(function () {
                this.partial('./templates/CreateNewOffer.hbs');
            })
    })

    this.post('/createNewOffer', function (context) {
        const { productName, price, img, description, brand } = context.params;
        DB.collection('dataBase').add({
            productName,
            price,
            img,
            description,
            brand,
            salesman: getUserInfo().uid,
        })
            .then((data) => {
                // console.log(data);
                this.redirect('#/home')
            })
            .catch((error) => {
                console.log(error);
            })
    })

    this.get('/logout', function () {
        userModel.signOut()
            .then(() => {
                localStorage.removeItem('user');
                this.redirect('#/home');
            })
            .catch((error) => {
                console.log(error);
            })
    })

    this.get('/edit/:id', function (context) {
        // console.log(context);
        const { id } = context.params;
        DB.collection('dataBase')
            .doc(id)
            .get()
            .then((response) => {
                // console.log(response);
                // console.log(context);
                context.shoesCollection = { id: id, ...response.data() };
                addHeaderFooter(context)
                    .then(function () {
                        this.partial('./templates/editOffer.hbs');
                    })
            })
    })

    this.post('edit/:id' , function(context) {
        console.log(context);
        const {id, productName, price, brand, description, img} = context.params;

        DB.collection('dataBase')
        .doc(id)
        .get()
        .then((response) => {
            return DB.collection('dataBase')
            .doc(id)
            .set({
                ...response.data(),
                productName,
                price,
                brand,
                description,
                img,
            })
        })
        .then((response) => {
            this.redirect(`#/details/${id}`)
        })
        .catch((error) => 
        console.log(error));
    })

});

(() => {
    app.run('#/home');
})();

function addHeaderFooter(context) {
    context.isLoggedIn = Boolean(getUserInfo());
    context.email = getUserInfo() ? getUserInfo().email : "";

    return context.loadPartials({
        'header': './partials/header.hbs',
        'footer': './partials/footer.hbs'
    })
}

function getUserInfo() {
    let currentUser = localStorage.getItem('user');
    if (currentUser) {
        return (JSON.parse(currentUser));
        // console.log("emeil " + info.email);
        // console.log("uid " + info.uid);

    } else {
        null;
    }
}

// function getUserInfoUid() {
//     let currentUser = localStorage.getItem('user');
//     if (currentUser) {
//         let info = (JSON.parse(currentUser));
//         return info.uid;
//         // console.log("emeil " + info.email);
//         // console.log("uid " + info.uid);
//     } else {
//         null;
//     }
// }